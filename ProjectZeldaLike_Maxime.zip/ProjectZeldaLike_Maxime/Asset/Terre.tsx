<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="Terre" tilewidth="32" tileheight="32" tilecount="345" columns="23">
 <image source="Terre.png" width="750" height="500"/>
</tileset>
